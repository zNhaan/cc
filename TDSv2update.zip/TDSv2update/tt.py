import mechanize,re
import http.cookiejar as cookielib
from colorama import *
def Cookie(user,passwd):
    user = user
    passwd = passwd
    url = "https://m.facebook.com/login.php"

    br = mechanize.Browser()
    cookiejar = cookielib.LWPCookieJar()
    br.set_cookiejar( cookiejar )
    br.set_handle_equiv( True )
    br.set_handle_gzip( True )
    br.set_handle_redirect( True ) 
    br.set_handle_referer( True )
    br.set_handle_robots( False )

    br.set_handle_refresh( mechanize._http.HTTPRefreshProcessor(), max_time = 1)
    br.addheaders = [ ( 'User-agent', '	Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15' ) ]


    #Open URL and submit
    br.open(url)
    br.select_form(nr=0)
    br.form['email'] = user
    br.form['pass'] = passwd
    response = br.submit()
    cookies = ""
    for i in br._ua_handlers['_cookies'].cookiejar :
        cookies += str(i).split('<Cookie ')[1].split(' for .facebook.com/>')[0] +';'
    return cookies
def GETUSERID(user,passwd):
    user = user
    passwd = passwd
    url = "https://m.facebook.com/login.php"

    br = mechanize.Browser()
    cookiejar = cookielib.LWPCookieJar()
    br.set_cookiejar( cookiejar )
    br.set_handle_equiv( True )
    br.set_handle_gzip( True )
    br.set_handle_redirect( True ) 
    br.set_handle_referer( True )
    br.set_handle_robots( False )

    br.set_handle_refresh( mechanize._http.HTTPRefreshProcessor(), max_time = 1)
    br.addheaders = [ ( 'User-agent', '	Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15' ) ]


    #Open URL and submit
    br.open(url)
    br.select_form(nr=0)
    br.form['email'] = user
    br.form['pass'] = passwd
    response = br.submit()
    INFO = response.read()
    USERIDGET = re.findall('"userID".*?,',str(INFO))
    
    try:
        ID = str(USERIDGET[0]).replace('"userID":','').replace(',','')
        print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.GREEN+'\u0110\u0103\u006e\u0067\u0020\u004e\u0068\u1ead\u0070\u0020\u0054\u0068\u00e0\u006e\u0068\u0020\u0043\u00f4\u006e\u0067\u0020\u005b\u003a\u0033\u005d')
        return ID
    except IndexError:
        print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.RED+'\u0110\u0103\u006e\u0067\u0020\u004e\u0068\u1ead\u0070\u0020\u0054\u0068\u1ea5\u0074\u0020\u0042\u1ea1\u0069\u0020\u005b\u003a\u0028\u005d')
        return 0

# GETUSERID('vinhytb3010@gmail.com','deno4121997')