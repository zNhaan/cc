import requests,re
from colorama import *
from art import *
from hypercli import hypercli
import os
import data1
from time import sleep
import random
import tt
def countdown(time_sec):
    while time_sec:
        mins, secs = divmod(time_sec, 60)
        timeformat = Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0110\u0061\u006e\u0067\u0020\u004e\u0067\u0068\u1ec9\u0020\u0044\u0065\u006c\u0061\u0079\u0020\u003a\u0020 {:02d}'.format(secs)
        print(timeformat, end='\r')
        sleep(1)
        time_sec -= 1
def LOADCOOKIE(time_sec):
    while time_sec:
        mins, secs = divmod(time_sec, 60)
        timeformat = Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0110\u0061\u006e\u0067\u0020\u004c\u1ea5\u0079\u0020\u0043\u006f\u006f\u006b\u0069\u0065\u0020\u0056\u0075\u0069\u0020\u004c\u006f\u006e\u0067\u0020\u0043\u0068\u1edd\u0020\u003a\u0020 {:02d}'.format(secs)
        print(timeformat, end='\r')
        sleep(1)
        time_sec -= 1
def CHONGBLOCK(time_sec):
    while time_sec:
        mins, secs = divmod(time_sec, 60)
        timeformat = Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0110\u0061\u006e\u0067\u0020\u004c\u1ea5\u0079\u0020\u0043\u006f\u006f\u006b\u0069\u0065\u0020\u0056\u0075\u0069\u0020\u004c\u006f\u006e\u0067\u0020\u0043\u0068\u1edd\u0020\u003a\u0020 {:02d}'.format(secs)
        print(timeformat, end='\r')
        sleep(1)
        time_sec -= 1
cli = hypercli()
def Header():
    cli.config["banner_text"] = "\u0044\u0045\u004e\u004f"
    cli.config["intro_title"] = "\u0054\u004f\u004f\u004c\u0020\u0054\u0044\u0053\u0020\u0056\u0031"
    cli.config["intro_content"] = "\u0054\u004f\u004f\u004c\u0020\u0042\u0059\u0020\u0044\u0045\u004e\u004f\n\u0046\u0042\u0020\u003a\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0066\u0061\u0063\u0065\u0062\u006f\u006f\u006b\u002e\u0063\u006f\u006d\u002f\u0061\u0063\u0063\u006e\u0067\u0075\u006e\u0067\u0068\u006f\u0061\u0074\u0064\u006f\u006e\u0067\u0072\u0065\u0061\u006c \n \u0059\u004f\u0055\u0054\u0055\u0042\u0045\u0020\u003a\u0020\u0057\u004e\u0045\u2122 \n \u0054\u0069\u006b\u0074\u006f\u006b\u0020\u003a\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0074\u0069\u006b\u0074\u006f\u006b\u002e\u0063\u006f\u006d\u002f\u0040\u0064\u0065\u006e\u006f\u0076\u0069\u0065\u0074\u0074\u006f\u006f\u006c"
    cli.config["show_menu_table_header"] = True
Header()
@cli.entry(menu="Main Menu", option="TOOL TDS V1.0")
def greet():
   os.system('cls' if os.name== 'nt' else 'clear')
   print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'TOOL : '+Fore.BLUE+'TDS')
   print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'YOUTUBE : '+Fore.BLUE+'https://www.youtube.com/@wne9838')
   print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'ADMIN : '+Fore.BLUE+'DENO')
   print(Fore.RED+'_______________________________________________________________________')
   
   checkfile2 = os.path.isfile('Access_token.txt')
   if checkfile2 == False:
        TOKEN = input(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'Access_token : ')
        createfile = open('Access_token.txt','w')
        createfile.write(TOKEN)
        createfile.close()
        readfile = open('Access_token.txt','r')
        TOKEN = readfile.read()
        readfile.close()
   else:
        readfile = open('Access_token.txt','r')
        TOKEN = readfile.read()
        readfile.close()
   url = 'https://traodoisub.com/api/?fields=profile&access_token='+TOKEN
   USER = requests.get(url).json()
   if 'success' in str(USER):
       os.system('cls' if os.name== 'nt' else 'clear')
       print(Fore.RED+'_______________________________________________________________________')
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0054\u00ea\u006e\u0020\u0054\u00e0\u0069\u0020\u004b\u0068\u006f\u1ea3\u006e\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['user'])
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0058\u0075\u0020\u0048\u0069\u1ec7\u006e\u0020\u0054\u1ea1\u0069\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['xu'])
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0058\u0075\u0020\u0042\u1ecb\u0020\u0050\u0068\u1ea1\u0074\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['xudie'])
       print(Fore.RED+'_______________________________________________________________________')
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+Fore.GREEN+'\u004e\u0068\u1ead\u0070 '+Fore.CYAN+'['+Fore.YELLOW+'1'+Fore.CYAN+']'+Fore.GREEN+' \u0110\u1ec3\u0020\u0043\u0068\u1ea1\u0079\u0020\u0054\u006f\u006f\u006c\u0020\u004c\u0069\u006b\u0065\u0020\u0056\u00e0\u0020\u0043\u1ea3\u006d\u0020\u0058\u00fa\u0063'+' Facebook')
       choose1 = input('\n\n\n'+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u004c\u1ef1\u0061\u0020\u0043\u0068\u1ecd\u006e\u0020\u0043\u1ee7\u0061\u0020\u0042\u1ea1\u006e\u0020\u003a\u0020 ')
       DELAYMIN = int(input(''+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'DELAY MIN : '))
       DELAYMAX = int(input(''+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'DELAY MAX : '))
       os.system('cls' if os.name== 'nt' else 'clear')
       print(Fore.RED+'_______________________________________________________________________')
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'TOOL : '+Fore.BLUE+'TDS')
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'YOUTUBE : '+Fore.BLUE+'https://www.youtube.com/@wne9838')
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'ADMIN : '+Fore.BLUE+'DENO')
       print(Fore.RED+'_______________________________________________________________________')
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+Fore.GREEN+'\u004e\u0068\u1ead\u0070 '+Fore.CYAN+'['+Fore.YELLOW+'1'+Fore.CYAN+']'+Fore.GREEN+' \u0053\u1eed\u0020\u0044\u1ee5\u006e\u0067'+' COOKIE ')
       print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+Fore.GREEN+'\u004e\u0068\u1ead\u0070 '+Fore.CYAN+'['+Fore.YELLOW+'2'+Fore.CYAN+']'+Fore.GREEN+' \u0053\u1eed\u0020\u0044\u1ee5\u006e\u0067'+' \u0054\u00e0\u0069\u0020\u004b\u0068\u006f\u1ea3\u006e\u0020\u002b\u0020\u004d\u1ead\u0074\u0020\u004b\u0068\u1ea9\u0075 ')
       choose2 = int(input('\n\n\n'+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u004c\u1ef1\u0061\u0020\u0043\u0068\u1ecd\u006e\u0020\u0043\u1ee7\u0061\u0020\u0042\u1ea1\u006e\u0020\u003a\u0020 '))
       if choose2 == 1:
            print(Fore.RED+'_______________________________________________________________________')
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0054\u00ea\u006e\u0020\u0054\u00e0\u0069\u0020\u004b\u0068\u006f\u1ea3\u006e\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['user'])
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0058\u0075\u0020\u0048\u0069\u1ec7\u006e\u0020\u0054\u1ea1\u0069\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['xu'])
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0058\u0075\u0020\u0042\u1ecb\u0020\u0050\u0068\u1ea1\u0074\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['xudie'])
            print(Fore.RED+'_______________________________________________________________________')
            os.system('cls' if os.name== 'nt' else 'clear')
            print(Fore.RED+'_______________________________________________________________________')
            IDCAUHINH = input(''+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u0049\u0044\u0020\u0046\u0061\u0063\u0065\u0062\u006f\u006f\u006b\u0020\u0043\u1ea5\u0075\u0020\u0048\u00ec\u006e\u0068\u0020\u003a\u0020')
            data = data1.CAUHINH(TOKEN,IDCAUHINH)
            if data == 1:
               checkfile2 = os.path.isfile('COOKIE'+str(IDCAUHINH)+'.txt')
               if checkfile2 == False:
                         COOKIE  = input('\n\n\n'+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u0043\u006f\u006f\u006b\u0069\u0065\u0020\u003a\u0020')
                         createfile = open('COOKIE'+str(IDCAUHINH)+'.txt','w')
                         createfile.write(COOKIE)
                         createfile.close()
                         readfile = open('COOKIE'+str(IDCAUHINH)+'.txt','r')
                         COOKIE = readfile.read()
                         readfile.close()
               else:
                         readfile = open('COOKIE'+str(IDCAUHINH)+'.txt','r')
                         COOKIE = readfile.read()
                         readfile.close()
               sleep(2)
               os.system('cls' if os.name== 'nt' else 'clear')
               print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'COOKIE : '+Fore.BLUE+COOKIE)
               print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+Fore.GREEN+'\u004e\u0068\u1ead\u0070 '+Fore.CYAN+'['+Fore.YELLOW+'1'+Fore.CYAN+']'+Fore.GREEN+' \u0047\u0069\u1eef\u0020\u004c\u1ea1\u0069\u0020\u0054\u0068\u00f4\u006e\u0067\u0020\u0054\u0069\u006e')
               print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+Fore.GREEN+'\u004e\u0068\u1ead\u0070 '+Fore.CYAN+'['+Fore.YELLOW+'2'+Fore.CYAN+']'+Fore.GREEN+' \u0054\u0068\u0061\u0079\u0020\u0054\u0068\u00f4\u006e\u0067\u0020\u0054\u0069\u006e\u0020\u004b\u0068\u00e1\u0063')
               choose = int(input('\n\n\n'+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u004c\u1ef1\u0061\u0020\u0043\u0068\u1ecd\u006e\u0020\u0043\u1ee7\u0061\u0020\u0042\u1ea1\u006e\u0020\u003a\u0020 '))
               if choose == 1:
                    readfile = open('COOKIE'+str(IDCAUHINH)+'.txt','r')
                    COOKIE = readfile.read()
                    readfile.close()
               elif choose == 2:
                    os.remove('COOKIE'+str(IDCAUHINH)+'.txt')
                    return 0
            os.system('cls' if os.name== 'nt' else 'clear')
            print(Fore.RED+'_______________________________________________________________________')
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'TOOL : '+Fore.BLUE+'Traodoisub')
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'YOUTUBE : '+Fore.BLUE+'https://www.youtube.com/@wne9838')
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'ADMIN : '+Fore.BLUE+'DENO')
            print(Fore.RED+'_______________________________________________________________________')
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0043\u006f\u006f\u006b\u0069\u0065\u0020\u0043\u1ee7\u0061\u0020\u0042\u1ea1\u006e\u0020\u003a\u0020'+Fore.BLUE+COOKIE)
            for i in range(100000000):
                 data1.LIKE(TOKEN,COOKIE)
                 countdown(random.randint(DELAYMIN,DELAYMAX))
                 data1.LIKEGIARE(TOKEN,COOKIE)
                 countdown(random.randint(DELAYMIN,DELAYMAX))
                 data1.LIKESIEURE(TOKEN,COOKIE)
                 countdown(random.randint(DELAYMIN,DELAYMAX))
                 data1.REACTION(TOKEN,COOKIE)
                 countdown(random.randint(DELAYMIN,DELAYMAX))

       elif choose2 ==2:
            os.system('cls' if os.name== 'nt' else 'clear')
            print(Fore.RED+'_______________________________________________________________________')
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0054\u00ea\u006e\u0020\u0054\u00e0\u0069\u0020\u004b\u0068\u006f\u1ea3\u006e\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['user'])
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0058\u0075\u0020\u0048\u0069\u1ec7\u006e\u0020\u0054\u1ea1\u0069\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['xu'])
            print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0058\u0075\u0020\u0042\u1ecb\u0020\u0050\u0068\u1ea1\u0074\u0020\u003a\u0020 '+Fore.BLUE+USER['data']['xudie'])
            print(Fore.RED+'_______________________________________________________________________')
            FIlE = int(input(''+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u0044\u1ecb\u006e\u0068\u0020\u0053\u1ed1\u0020\u0043\u1ee7\u0061\u0020\u0046\u0069\u006c\u0065\u0020\u0028\u0056\u0044\u003a\u0020\u0031\u0032\u0033\u0034\u002d\u003e\u0075\u0073\u0065\u0072\u0031\u0032\u0033\u0034\u002e\u0074\u0078\u0074\u002c\u0020\u0070\u0061\u0073\u0073\u0031\u0032\u0033\u0034\u002e\u0074\u0078\u0074\u0029\u0020\u003a\u0020'))
            checkfileuser = os.path.isfile('USER'+str(FIlE)+'.txt')
            if checkfileuser == False:
                    USER  = input(''+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u0045\u006d\u0061\u0069\u006c\u0020\u002f\u0020\u0053\u1ed1\u0020\u0110\u0069\u1ec7\u006e\u0020\u0054\u0068\u006f\u1ea1\u0069\u0020\u003a\u0020\u0020')
                    createfile = open('USER'+str(FIlE)+'.txt','w')
                    createfile.write(USER)
                    createfile.close()
                    readfile = open('USER'+str(FIlE)+'.txt','r')
                    USER = readfile.read()
                    readfile.close()
            else:
                    readfile = open('USER'+str(FIlE)+'.txt','r')
                    USER = readfile.read()
                    readfile.close()
            checkfilepass = os.path.isfile('PASSWD'+str(FIlE)+'.txt')
            if checkfilepass == False:
                    PASSWD  = input(''+Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u004e\u0068\u1ead\u0070\u0020\u0050\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u0020\u003a\u0020')
                    createfile = open('PASSWD'+str(FIlE)+'.txt','w')
                    createfile.write(PASSWD)
                    createfile.close()
                    readfile = open('PASSWD'+str(FIlE)+'.txt','r')
                    PASSWD = readfile.read()
                    readfile.close()
            else:
                    readfile = open('PASSWD'+str(FIlE)+'.txt','r')
                    PASSWD = readfile.read()
                    readfile.close()
            checklogin = tt.GETUSERID(USER,PASSWD)
            if checklogin != 0:
                  data1.CAUHINH(TOKEN,checklogin)
                  LOADCOOKIE(2)
                  Cookie2 = tt.Cookie(USER,PASSWD)
                  print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'COOKIE : '+Fore.BLUE+Cookie2)
                  print(Fore.RED+'_______________________________________________________________________')
                  for i in range(100000000):
                    data1.LIKE(TOKEN,Cookie2)
                    countdown(random.randint(DELAYMIN,DELAYMAX))
                    data1.LIKEGIARE(TOKEN,Cookie2)
                    countdown(random.randint(DELAYMIN,DELAYMAX))
                    data1.LIKESIEURE(TOKEN,Cookie2)
                    countdown(random.randint(DELAYMIN,DELAYMAX))
                    data1.REACTION(TOKEN,Cookie2)
                    countdown(random.randint(DELAYMIN,DELAYMAX))
                    print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'COOKIE : '+Fore.BLUE+Cookie2)
                    print(Fore.RED+'_______________________________________________________________________')
            else:
                  os.remove('USER'+str(FIlE)+'.txt')
                  os.remove('PASSWD'+str(FIlE)+'.txt')
                  return 0

   else:    
       print(USER['error'])
cli.run()