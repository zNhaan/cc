import requests,re
import base64
def FB(cookiesX,react,ID_JOB):
    cookies = {
        'sb': cookiesX.split('sb=')[1].split(';')[0],
        'datr': cookiesX.split('datr=')[1].split(';')[0],
        'c_user': cookiesX.split('c_user=')[1].split(';')[0],
        'xs': cookiesX.split('xs=')[1].split(';')[0],
        'fr': cookiesX.split('fr=')[1].split(';')[0],
    }
    headers = {
        'accept': '*/*',
        'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
        'content-type': 'application/x-www-form-urlencoded',
        # 'cookie': 'datr=LimoZiOW78YJ1BBxxxntecZy; ps_l=1; ps_n=1; sb=XyqoZl_z-ywr74mdUcCFFcaf; dpr=1.5625; c_user=100041984710675; fr=1uyXez4qxUG5dXcbW.AWUqQTHhSyE03muEnVo2gYI5mcs.BmqGPk..AAA.0.0.BmqGPk.AWULXjnGn2M; xs=4%3AFIBR8ibhPU70xg%3A2%3A1722309827%3A-1%3A6312%3A%3AAcU26-9RnH7GJdNRmbOf_IHCmeNUUbbs9rXCXpOK3g; presence=C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1722311654685%2C%22v%22%3A1%7D; wd=678x584',
        'origin': 'https://www.facebook.com',
        'priority': 'u=1, i',
        'referer': 'https://www.facebook.com/photo/?fbid=417986634414551&set=a.112237031656181',
        'sec-ch-prefers-color-scheme': 'dark',
        'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
        'sec-ch-ua-full-version-list': '"Not)A;Brand";v="99.0.0.0", "Google Chrome";v="127.0.6533.73", "Chromium";v="127.0.6533.73"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"15.0.0"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        'x-asbd-id': '129477',
        'x-fb-friendly-name': 'CometUFIFeedbackReactMutation',
        'x-fb-lsd': 'XoO-HPUEBt2-pU3v3WYBIL',
    }
    #react
    try:
        index = 1635855486666999 if react == 'LIKE' or react == 'like' or react == 'likegiare' or react == 'likesieure' else 1678524932434102 if react =='LOVE' else 613557422527858 if react == 'CARE' else 115940658764963 if react == 'HAHA' else 478547315650144 if react=='WOW' else 908563459236466 if react =='SAD' else 444813342392137 if react=='ANGRY' else 0
        response = requests.get('https://www.facebook.com/'+str(ID_JOB),headers=headers,cookies=cookies).url
        check = requests.get(response,headers=headers,cookies=cookies).text
        baseurl = requests.get('https://mbasic.facebook.com',headers=headers,cookies=cookies).text
        av = re.findall('action="/composer.*?&',baseurl)
        ACTOR_ID = str(av).split('av=')[1].split('&')[0]
        dtsgget = re.findall('{"u".*?}',check)
        fb_dtsg = str(dtsgget).split('"f":"')[1].split('"')[0]
        if 'reel' in str(response) or 'watch' in str(response) or 'videos' in str(response):
            
            LINK = str(response).replace('https://www.facebook.com/','https://mbasic.facebook.com/')
            ID = requests.get(LINK,headers=headers,cookies=cookies).text
            UIDGET = re.findall('target_id.*?&',ID)
            UIDGET = re.findall('like_.*?"',ID)
            UID = str(UIDGET[0]).split('like_')[1].split('"')[0]
            node = 'feedback:'+UID
            base64_id = base64.b64encode(node.encode('utf-8'))
            fbid = str(base64_id).replace("b'","").replace("'","")
        else:
            LINK = str(response).replace('https://www.facebook.com/','https://mbasic.facebook.com/')
            ID = requests.get(LINK,headers=headers,cookies=cookies).text
            UIDGET = re.findall('target_id.*?&',ID)
            UID = str(UIDGET).split('target_id=')[1].split('&')[0]
            node = 'feedback:'+UID
            base64_id = base64.b64encode(node.encode('utf-8'))
            fbid = str(base64_id).replace("b'","").replace("'","")
        data = {
            'fb_dtsg': fb_dtsg,
            'variables': '{"input":{"attribution_id_v2":"CometPhotoRoot.react,comet.mediaviewer.photo,via_cold_start,1722312271734,972485,,,","feedback_id":"'+fbid+'","feedback_reaction_id":"'+str(index)+'","feedback_source":"MEDIA_VIEWER","is_tracking_encrypted":true,"tracking":[],"session_id":"e4a672bb-0a05-4edf-a3e1-a0f30f085423","actor_id":"'+ACTOR_ID+'","client_mutation_id":"1"},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}',
            'doc_id': '7616998081714004',
        }
        response = requests.post('https://www.facebook.com/api/graphql/', cookies=cookies, headers=headers, data=data).text
           
        return True

    except IndexError:
        pass
        return False