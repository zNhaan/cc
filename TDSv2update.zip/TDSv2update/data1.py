import requests,re
from colorama import Fore
from art import *
import random
from time import sleep
import fb1
import FB
def countdown(time_sec):
    while time_sec:
        mins, secs = divmod(time_sec, 60)
        timeformat = Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0110\u0061\u006e\u0067\u0020\u004c\u1ea5\u0079\u0020\u004e\u0068\u0069\u1ec7\u006d\u0020\u0056\u1ee5\u0020\u003a\u0020 {:02d}'.format(secs)
        print(timeformat, end='\r')
        sleep(1)
        time_sec -= 1
def countdownagain(time_sec):
    while time_sec:
        mins, secs = divmod(time_sec, 60)
        timeformat = Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0043\u0068\u0065\u0063\u006b\u0020\u004c\u1ea1\u0069\u0020\u004a\u006f\u0062\u0020\u003a\u0020 {:02d}'.format(secs)
        print(timeformat, end='\r')
        sleep(1)
        time_sec -= 1
def CAUHINH(TOKEN,fbid):
    url = 'https://traodoisub.com/api/?fields=run&id='+fbid+'&access_token='+TOKEN
    CAUHINHACC = requests.get(url).json()
    if 'success' in str(CAUHINHACC):
        print(Fore.RED+'____________________________________________________________________')
        print(Fore.GREEN+str(CAUHINHACC['success'])+' '+'|'+Fore.YELLOW+CAUHINHACC['data']['id']+' '+'|'+Fore.BLUE+CAUHINHACC['data']['msg'])
        print(Fore.RED+'____________________________________________________________________')
        sleep(2)
        return 1
    else:
        print(Fore.RED+'CAU HINH THAT BAI !')
        return 0
def LIKE(TOKEN,COOKIE):
    TYPE = 'like'
    url = 'https://traodoisub.com/api/?fields='+TYPE+'&access_token='+TOKEN
    JOB = requests.get(url).text
    if "error" in str(JOB):
        pass
    else:
        id = re.findall(': ".*?"',JOB)
        for i in range(len(id)):
            ID_JOB = str(id[i]).replace(': "','').replace('"','')

            countdown(random.randint(2,3))
            fb1.FB(COOKIE,TYPE,ID_JOB)
            CPJOB(TOKEN,TYPE,ID_JOB)
            
def LIKEGIARE(TOKEN,COOKIE):
    TYPE = 'likegiare'
    url = 'https://traodoisub.com/api/?fields='+TYPE+'&access_token='+TOKEN
    JOB = requests.get(url).text
    if "error" in str(JOB):
        pass
    else:
        id = re.findall(': ".*?"',JOB)
        for i in range(len(id)):
            ID_JOB = str(id[i]).replace(': "','').replace('"','')

            countdown(random.randint(2,3))
            fb1.FB(COOKIE,TYPE,ID_JOB)
            CPJOB(TOKEN,TYPE,ID_JOB)
def LIKESIEURE(TOKEN,COOKIE):
    TYPE = 'likesieure'
    url = 'https://traodoisub.com/api/?fields='+TYPE+'&access_token='+TOKEN
    JOB = requests.get(url).text
    if "error" in str(JOB):
        pass
    else:
        id = re.findall(': ".*?"',JOB)
        for i in range(len(id)):
            ID_JOB = str(id[i]).replace(': "','').replace('"','')

            countdown(random.randint(2,3))
            fb1.FB(COOKIE,TYPE,ID_JOB)
            CPJOB(TOKEN,TYPE,ID_JOB)
def REACTION(TOKEN,COOKIE):
    url = 'https://traodoisub.com/api/?fields=reaction&access_token='+TOKEN
    JOB = requests.get(url).text
    id = re.findall('"id".*?,',JOB)
    type = re.findall('"type".*',JOB)
    for i in range(len(id)):
       ID_JOB = str(id[i]).replace('"id": "','').replace('",','')
       TYPE = str(type[i]).replace('"type": "','').replace('"','')
       countdown(random.randint(2,3))
       fb1.FB(COOKIE,TYPE,ID_JOB)
       CPJOB(TOKEN,TYPE,ID_JOB)
def CPJOB(TOKEN,TYPE,IDJOB):
    url = 'https://traodoisub.com/api/coin/?type='+TYPE+'&id='+IDJOB+'&access_token='+TOKEN
    check = requests.get(url).json()
    if 'success' in str(check):
       print(Fore.GREEN+str(check['success'])+' '+'|'+Fore.CYAN+TYPE+'| '+Fore.YELLOW+check['data']['id']+' '+'|'+Fore.BLUE+check['data']['msg']) 
    else:
        countdownagain(2)
        url = 'https://traodoisub.com/api/coin/?type='+TYPE+'&id='+IDJOB+'&access_token='+TOKEN
        check = requests.get(url).json()
        if 'success' in str(check):
            print(Fore.GREEN+str(check['success'])+' '+'|'+Fore.CYAN+TYPE+'| '+Fore.YELLOW+check['data']['id']+' '+'|'+Fore.BLUE+check['data']['msg']) 
        else:
            pass