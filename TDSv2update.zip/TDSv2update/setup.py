import os
os.system('pip install hypercli')
os.system('pip install art')
os.system('pip install colorama')
os.system('pip install mechanize')
os.system('pip install http.cookiejar')
from colorama import Fore
print(Fore.RED+'['+Fore.WHITE+'=.='+Fore.RED+']' + Fore.BLUE+' => '+Fore.LIGHTRED_EX+'\u0110\u00e3\u0020\u0053\u0065\u0074\u0075\u0070\u0020\u0058\u006f\u006e\u0067\u0020\u0021')